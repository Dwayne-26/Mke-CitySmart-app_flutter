# CitySmart App Source Bundle (v1.6)
Complete FastAPI + Flutter bundle for the CitySmart application.
Includes:
- Backend APIs for parking, EV, garbage, notifications
- Flutter widgets for UI (splash, map legend, prediction bar)
- Branding (colors, fonts, logo)
- Branding Preview Screen (branding_preview.dart)
